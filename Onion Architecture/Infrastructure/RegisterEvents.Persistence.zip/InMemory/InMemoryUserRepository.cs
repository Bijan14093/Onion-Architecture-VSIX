﻿using RegisterEvents.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.InMemory
{
    class InMemoryUserRepository : RegisterEvents.Domain.Repositories.IUserRepository
    {
        private List<User> users =null;

        public User GetByUserName(string UserName)
        {
            if (users == null)
            {
                users = new List<User>();
                users.Add(new User { ID =Guid.NewGuid() , UserName = "Bijan", Password = "1234" });
                users.Add(new User { ID = Guid.NewGuid() , UserName = "rw", Password = "1234" });
            }
            return users.Where(x => x.UserName == UserName).FirstOrDefault();

        }


        public void Insert(User user)
        {
            throw new NotImplementedException();
        }

        public void Remove(User user)
        {
            throw new NotImplementedException();
        }
    }
}
