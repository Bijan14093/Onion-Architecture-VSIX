﻿using System;
using $ext_projectname$.Domain.Repositories;
using $ext_projectname$.IServices;
using $safeprojectname$;

namespace $safeprojectname$
{
    public sealed class ServiceManager : IServiceManager
    {
        private readonly Lazy<IUserAccountService> _lazyUserAccountService;

        public ServiceManager(IRepositoryManager repositoryManager)
        {
            _lazyUserAccountService = new Lazy<IUserAccountService>(() => new UserAccountService(repositoryManager));
        }

        public IUserAccountService UserAccountService => _lazyUserAccountService.Value;

    }
}
