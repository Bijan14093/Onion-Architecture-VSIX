﻿using $safeprojectname$.Entities;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;


namespace $safeprojectname$.Repositories
{
    public interface IUserRepository
    {
        User GetByUserName(string UserName);

        void Insert(User user);

        void Remove(User user);
    }
}
