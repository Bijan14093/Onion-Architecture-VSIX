﻿namespace $safeprojectname$
{
    public static class AssemblyReference
    {
    }
}
