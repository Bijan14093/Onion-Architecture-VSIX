﻿using $ext_projectname$.DTO;
using System;

namespace $safeprojectname$
{
    public interface IUserAccountService
    {
        bool IsAuthenticated(Userdto user);
    }
}
