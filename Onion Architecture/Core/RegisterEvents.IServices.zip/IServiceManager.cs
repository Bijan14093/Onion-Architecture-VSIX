﻿using $safeprojectname$;

namespace $safeprojectname$
{
    public interface IServiceManager
    {
        IUserAccountService UserAccountService { get; }

    }
}
