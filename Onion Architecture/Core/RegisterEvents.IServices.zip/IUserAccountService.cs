﻿using RegisterEvents.DTO;
using System;

namespace $safeprojectname$
{
    public interface IUserAccountService
    {
        bool IsAuthenticated(Userdto user);
    }
}
