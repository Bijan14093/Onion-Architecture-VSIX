﻿using System;
using RegisterEvents.Domain.Repositories;
using RegisterEvents.IServices;
using $safeprojectname$;

namespace $safeprojectname$
{
    public sealed class ServiceManager : IServiceManager
    {
        private readonly Lazy<IUserAccountService> _lazyUserAccountService;

        public ServiceManager(IRepositoryManager repositoryManager)
        {
            _lazyUserAccountService = new Lazy<IUserAccountService>(() => new UserAccountService(repositoryManager));
        }

        public IUserAccountService UserAccountService => _lazyUserAccountService.Value;

    }
}
