﻿using RegisterEvents.Domain.Repositories;
using RegisterEvents.DTO;
using RegisterEvents.IServices;
using System;

namespace $safeprojectname$
{
    public class UserAccountService:IUserAccountService
    {
        private readonly IRepositoryManager _repositoryManager;
        public UserAccountService(IRepositoryManager repositoryManager)
        {
            _repositoryManager=repositoryManager;
    }
        public bool IsAuthenticated(Userdto user)
        {
            var dbuser = _repositoryManager.UserRepository.GetByUserName(user.UserName);
            if (dbuser==null)
            {
                return false;
            }
            if (dbuser.Password!= user.Password)
            {
                return false;
            }

            return true;
        }

    }
}
